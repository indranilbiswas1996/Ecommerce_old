<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
/**
 * Created by IntelliJ IDEA.
 * User: INDRANIL
 * Date: 9/5/2019
 * Time: 11:58 PM
 */
session_destroy();
header("Location: /Ecommerce/slogin.php");
?>