<div class="header-container">
    <div class="logo-container">
        <a href="#">
            <img src="icons/2.png" class="icon">
        </a>
    </div>
    <div class="blank-container"></div>
    <div class="name-container">
        <a href="/Ecommerce/slogin.php"><?php echo $profile_name?></a>
    </div>
    <div class="sign-out-container">
        <?php if(login_check() == true){ ?>
        <a href="/Ecommerce/logout.php"><span class="fa fa-sign-out"></span></a>
        <?php }?>
    </div>
</div>