<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == false){
    header("Location: /Ecommerce/slogin.php");
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<div class="container">
    <?php include 'sheader.php';?>
    <div class="control-container">
        <div class="control-option">
            <a href="#">Upload Product</a>
        </div>
        <div class="control-option">
            <a href="#">Products</a>
        </div>
        <div class="control-option">
            <a href="#">Orders</a>
        </div>
        <div class="control-option">
            <a href="#">Accepted</a>
        </div>
        <div class="control-option">
            <a href="#">Deleted</a>
        </div>
        <div class="control-option">
            <a href="#">Delivered</a>
        </div>
    </div>
</div>
</body>
</html>