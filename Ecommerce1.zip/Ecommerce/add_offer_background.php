<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                $offer_details =htmlspecialchars($_POST["offer_details"]);
                $offer_percentage = htmlspecialchars($_POST["offer_percentage"]);
                $max_offer =htmlspecialchars($_POST["max_offer"]);
                $min_order = htmlspecialchars($_POST["min_order"]);
                $offer_type =htmlspecialchars($_POST["offer_type"]);
                $start_date = htmlspecialchars($_POST["start_date"]);
                $end_date =htmlspecialchars($_POST["end_date"]);
                $offer_status = htmlspecialchars($_POST["offer_status"]);
                $offer_id_hidden =htmlspecialchars($_POST["offer_id_hidden"]);
                if(empty($offer_details)){
                    $code = 400;
                    $msg .= "<li>Enter offer details</li>";
                }  
                if(!is_numeric($offer_percentage)){
                    $code = 400;
                    $msg .= "<li>Invalid offer percentage</li>";
                }else{
                    if($offer_percentage < 0 || $offer_percentage > 100){
                        $code = 400;
                        $msg .= "<li>Offer percentage should be 0 to 100</li>";
                    }
                }
                if(!is_numeric($max_offer)){
                    $code = 400;
                    $msg .= "<li>Enter maximum offer</li>";
                }          
                if(!is_numeric($min_order)){
                    $code = 400;
                    $msg .= "<li>Enter minimum order</li>";
                }
                if($offer_type < 0){
                    $code = 400;
                    $msg .= "<li>Select offer type</li>";
                }
                if($start_date == ""){
                    $code = 400;
                    $msg .= "<li>Enter start date</li>";
                }else{
                    if($offer_id_hidden == 0){
                        $start_date = $start_date.":00";
                    }
                    $start_date = str_replace('T', ' ', $start_date);
                    if(!DateTime::createFromFormat('Y-m-d H:i:s', $start_date) && DateTime::createFromFormat('Y-m-d H:i:s', $start_date)->format('Y-m-d H:i:s') != $start_date){
                        $code = 400;
                        $msg .= "<li>Enter start date</li>";
                    }
                }
                if($end_date == ""){
                    $code = 400;
                    $msg .= "<li>Enter start date</li>";
                }else{
                    if($offer_id_hidden == 0){
                        $end_date = $end_date.":00";
                    }
                    $end_date = str_replace('T', ' ', $end_date);
                    if(!DateTime::createFromFormat('Y-m-d H:i:s', $end_date) && DateTime::createFromFormat('Y-m-d H:i:s', $end_date)->format('Y-m-d H:i:s') != $end_date){
                        $code = 400;
                        $msg .= "<li>Enter end date</li>";
                    }
                }
                if($offer_status < 0){
                    $code = 400;
                    $msg .= "<li>Select offer status</li>";
                }
                if(empty($msg)){
                    include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                    $shop_uid = $_SESSION['shop_uid'];
                    if($offer_id_hidden == 0){
                        $stmt = $conn->prepare("INSERT INTO offer(shop_uid, offer_details, offer_percentage, max_offer, min_order, start_date, end_date, offer_type, offer_status) VALUES (?,?,?,?,?,?,?,?,?)"); 
                        $stmt->bind_param('sssssssss', $shop_uid, $offer_details, $offer_percentage, $max_offer, $min_order, $start_date, $end_date, $offer_type, $offer_status);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }
                    if($offer_id_hidden > 0){
                        
                        $stmt = $conn->prepare("UPDATE offer SET offer_details=?,offer_percentage=?,max_offer=?,min_order=?,start_date=?,end_date=?,offer_type=?,offer_status=? WHERE id = ?"); 
                        $stmt->bind_param('sssssssss', $offer_details, $offer_percentage, $max_offer, $min_order, $start_date, $end_date, $offer_type, $offer_status, $offer_id_hidden);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }                    
                    $conn->close();
                }else{
                    $code = 400;
                }
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>