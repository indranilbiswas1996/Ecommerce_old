<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                $sub_category =htmlspecialchars($_POST["sub_category"]);
                $main_category_select =htmlspecialchars($_POST["main_category_select"]);
                $sub_category_hidden = htmlspecialchars($_POST["sub_category_hidden"]);
                if(empty($sub_category)){
                    $code = 400;
                    $msg .= "<li>Enter sub category</li>";
                }
                if($main_category_select <= 0 || $main_category_select == null){
                    $code = 400;
                    $msg .= "<li>Select main category</li>";
                }          
                if(empty($msg)){
                    include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                    $one = 1;
                    $shop_uid = $_SESSION['shop_uid'];
                    if($sub_category_hidden == 0){
                        $stmt = $conn->prepare("INSERT INTO product_sub_category (product_main_id,details,status) VALUES (?,?,?)"); 
                        $stmt->bind_param('sss', $main_category_select, $sub_category, $one);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }
                    if($sub_category_hidden > 0){
                        $code = 100;
                        $stmt = $conn->prepare("UPDATE product_sub_category SET details = ?, product_main_id = ? WHERE id = ?"); 
                        $stmt->bind_param('sss', $sub_category, $main_category_select , $sub_category_hidden);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }                 
                    $conn->close();
                }else{
                    $code = 400;
                }
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>