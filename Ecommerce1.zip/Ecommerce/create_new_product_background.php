<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                date_default_timezone_set('Asia/Kolkata');
                $unique_id = date('YmdGis').rand(100,999);
                $code = 200;
                $msg = $unique_id;
            }
            else{
                $code = 400;
                $msg = "Error";
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>