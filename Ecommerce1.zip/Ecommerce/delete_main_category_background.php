<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $main_category_id = htmlspecialchars($_POST["main_category_id"]);
                if($main_category_id > 0){
                    //----- Update product
                    $stmt2 = $conn->prepare("SELECT id FROM product_sub_category WHERE product_main_id = ?");
                    $stmt2->bind_param('s', $main_category_id);
                    $stmt2->execute();
                    $stmt2->store_result();
                    if($stmt2->num_rows() != 0){                    
                        $stmt2->bind_result($id);
                        while($stmt2->fetch()){
                            $stmt3 = $conn->prepare("UPDATE product SET product_sub_id = ? WHERE product_sub_id = ?"); 
                            $stmt3->bind_param('ss', $null, $id);
                            $stmt3->execute();
                            $stmt3->close();
                        }
                    }
                    $stmt2->close();

                    //----- Delete from product_sub_category
                    $stmt = $conn->prepare("DELETE FROM product_sub_category WHERE product_main_id = ?"); 
                    $stmt->bind_param('s', $main_category_id);
                    $stmt->execute();
                    $stmt->close();
                    
                    //----- Delete from product_main_category
                    $stmt4 = $conn->prepare("DELETE FROM product_main_category WHERE id = ?"); 
                    $stmt4->bind_param('s', $main_category_id);
                    $stmt4->execute();
                    $stmt4->close();
                    $code = 200;
                    $msg .= "Success";
                }                    
                $conn->close();
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>