<header>
    <div class="header">
        <a href="index.php" class="logo"><img src="icons/2.png" class="img-icon"></a>
    <div>
    <!--<a href="#home">Home</a>-->
    </div>
    <div class="header-right">
        <?php if(isset($_SESSION['phone'])){ ?>
            <a href="profile.php" class="login-box"><span class="fa fa-user-circle-o"></span><span> <?php echo $_SESSION['f_name'];?></span></a>
            <a href="logout.php" class="login-box"><span class="fa fa-sign-out"></span><span> Logout</span></a>
        <?php }else{?>
            <a href="login.php" class="login-box"><span class="fa fa-user-circle-o"></span><span> Login for existing sellers</span></a>
            <a href="registration.php"  class="registration-box">Register Now  <span class="fa fa-arrow-right"></span></a>
        <?php } ?>
    </div>
</header>