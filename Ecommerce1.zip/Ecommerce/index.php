<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == false){
    header("Location: login.php");
}else{
    if($_SESSION['shop_uid'] == null || $_SESSION['shop_uid'] == ""){
        header("Location: shop.php");
    }
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>        
        <div class="dashboard-details-container center">
            <div class="dashboard-details-inner-container">
                <div class="card-container">
                    <a href="#">
                        <span class="green"><span class="fa fa-dollar"></span></span>
                        <span class="green">25089</span>
                        <span class="background-green">Transaction</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="product.php">
                        <span class="sky"><span class="fa fa-shopping-bag"></span></span>
                        <span class="sky">25089</span>
                        <span class="background-sky">Products</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="offer.php">
                        <span class="violet"><span class="fa fa-percent"></span></span>
                        <span class="violet">25089</span>
                        <span class="background-violet">Offers</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="pink"><span class="fa fa-group"></span></span>
                        <span class="pink">25089</span>
                        <span class="background-pink">Group</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="sky"><span class="fa fa-cart-plus"></span></span>
                        <span class="sky">109</span>
                        <span class="background-sky">New orders</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="violet"><span class="fa fa-gift"></span></span>
                        <span class="violet">25089</span>
                        <span class="background-violet">Packed</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="blue"><span class="fa fa-truck"></span></span>
                        <span class="blue">201</span>
                        <span class="background-blue">Shipped</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="green"><span class="fa fa-dropbox"></span></span>
                        <span class="green">25089</span>
                        <span class="background-green">Delivered</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="pink"><span class="fa fa-undo"></span></span>
                        <span class="pink">25089</span>
                        <span class="background-pink">Returned</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="yellow"><span class="fa fa-exchange"></span></span>
                        <span class="yellow">25089</span>
                        <span class="background-yellow">Replacement</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="red"><span class="fa fa-close"></span></span>
                        <span class="red">25089</span>
                        <span class="background-red">Cancelled</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="blue"><span class="fa fa-star"></span></span>
                        <span class="blue">25089</span>
                        <span class="background-blue">Rating</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>