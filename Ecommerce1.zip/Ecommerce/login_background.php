<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() != true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $phone = htmlspecialchars($_POST["phone"]);
            $password = htmlspecialchars($_POST["password"]);
            if(empty($phone)){
                $code = 400;
                $msg .= "<li>Enter Mobile number</li>";
            }else{
                $phone = $_POST["phone"];
                if(!preg_match("/^[6-9]{1}[0-9]{9}$/", $phone)) {
                    $code = 400;
                    $msg .= "<li>Invalid Mobile no</li>";
                }
            }
            if(empty($_POST["password"])){
                $code = 400;
                $msg .= "<li>Enter Password</li>";
            }
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $zero = 0;
                $one = 1;
                $stmt = $conn->prepare("SELECT id, shop_uid, f_name, password, admin_status FROM admin WHERE phone = ?");        
                $stmt->bind_param('s', $phone);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $shop_uid, $f_name, $passwordHash, $admin_status);
                if($stmt->num_rows() == 1){
                    $stmt->fetch();
                    if(check_hash($_POST["password"],$passwordHash)){
                        $code = 200;
                            $msg = "Suss";
                        $_SESSION['phone'] = $phone;
                        $_SESSION['f_name'] = $f_name;
                        $_SESSION['shop_uid'] = $shop_uid;
                        if($admin_status == 1){
                            $_SESSION['logged_in'] = 1;
                            $_SESSION['admin_status'] = $one;
                            $code = 200;
                            $msg = "Success";
                        }else{
                            $_SESSION['admin_status'] = $zero;
                            $code = 201;
                            $msg = "Account not verified";
                            /* SMS and Mail*/
                            sendsmsotp($phone, $phone_otp);
                            sendemailotp($phone, $email_otp);
                        }
                    }else{
                        $code = 400;
                        $msg = "<li>Wrong password</li>";
                    }
                }
                else{
                    $code = 400;
                    $msg = "<li>Account Doesnt exist</li>";
                }
                $stmt->close();
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>