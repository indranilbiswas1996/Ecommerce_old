<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == false){
    header("Location: login.php");
}else{
    if($_SESSION['shop_uid'] == null || $_SESSION['shop_uid'] == ""){
        header("Location: shop.php");
    }
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
            <div class="dashboard-details-inner-container center">
                
                <div class="add-offer-container">
                    <div class="alert alert-danger" id="offer_err"></div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Offer details<span class="red">*</span></label>
                        <input type="text" name="offer_details" id="offer_details" class="login-textbox" placeholder="Enter offer details">
                        <input type="hidden" id="offer_id_hidden" value="0">
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Offer percentage<span class="red">*</span></label>
                        <input type="number" name="offer_percentage" id="offer_percentage" class="login-textbox" placeholder="Enter offer percentage.  Ex: 10">
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Maximum offer<span class="red">*</span></label>
                        <input type="number" name="max_offer" id="max_offer" class="login-textbox" placeholder="Enter maximum offer. Ex: 500">
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Minmum order<span class="red">*</span></label>
                        <input type="number" name="min_order" id="min_order" class="login-textbox" placeholder="Enter minmum order.  Ex: 500">
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Offer type<span class="red">*</span></label>
                        <select id="offer_type" name="offer_type" class="login-selectbox">
                            <option value="-1">Select offer type</option>
                            <option value="0">Local</option>
                            <option value="1">Global</option>
                        </select>
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Offer start date<span class="red">*</span></label>
                        <input type="datetime-local" name="start_date" id="start_date" class="login-textbox" placeholder="Enter start date">
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Offer end date<span class="red">*</span></label>
                        <input type="datetime-local" name="end_date" id="end_date" class="login-textbox" placeholder="Enter end date">
                    </div>
                    <div class="offer-textbox-container">
                        <label class="login-label">Offer status<span class="red">*</span></label>
                        <select id="offer_status" name="offer_status" class="login-selectbox">
                            <option value="-1">Select offer status</option>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                    <div class="offer-button-container">
                        <button type="submit" class="login-button" name="add_offer" id="add_offer" onclick="add_offer()">Add</button>
                    </div>
                    <div class="offer-button-container">
                        <button type="submit" class="login-button background-red"  onclick="reset_offer()">Reset</button>
                    </div>
                </div>
            </div>
            <div class="dashboard-details-inner-container center">
            <?php
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $stmt = $conn->prepare("SELECT id, offer_details, offer_percentage, max_offer, min_order, start_date, end_date, offer_type, offer_status FROM offer WHERE shop_uid = ?  ORDER BY offer_details ASC");
                $stmt->bind_param('s', $_SESSION['shop_uid']);
                $stmt->execute();
                $stmt->store_result();
                if($stmt->num_rows() != 0){                    
                    $stmt->bind_result($id, $offer_details, $offer_percentage, $max_offer, $min_order, $start_date, $end_date, $offer_type, $offer_status);
                    while($stmt->fetch()){
                        echo '<div class="offer-item-container">';
                        if($offer_status == 1){
                            echo '<div class="offer-item background-green white">';
                        }else{
                            echo '<div class="offer-item background-red white">';
                        }
                            
                            echo    $offer_details.
                                '<div class="offer-item-action">
                                    <span class="fa fa-edit white" onclick="edit_offer('.$id.',\''.$offer_details.'\',\''.$offer_percentage.'\',\''.$max_offer.'\',\''.$min_order.'\',\''.$start_date.'\',\''.$end_date.'\',\''.$offer_type.'\',\''.$offer_status.'\')"></span>
                                    <span class="fa fa-trash white" onclick="delete_offer('.$id.',\''.$offer_details.'\')"></span>
                                </div>
                            </div>
                            <div class="offer-all-details-container">
                                    <div>
                                        <span>Offer percentage</span>
                                        <span>'.$offer_percentage.'%</span>
                                    </div>
                                    <div>
                                        <span>Maximum offer</span>
                                        <span>'.$max_offer.'/-</span>
                                    </div>
                                    <div>
                                        <span>Manimum order</span>
                                        <span>'.$min_order.'/-</span>
                                    </div>
                                    <div>
                                        <span>Start date</span>
                                        <span>'.$start_date.'</span>
                                    </div>
                                    <div>
                                        <span>End date</span>
                                        <span>'.$end_date.'</span>
                                    </div>
                                    <div>
                                        <span>Offer type</span>
                                        <span>';
                                        if($offer_type == 1){
                                            echo 'Global';
                                        }else{
                                            echo 'Local';
                                        }
                                    echo '</span>
                                    </div>
                            </div>
                        </div>';
                    }
                }
                $stmt->close();
                $conn->close();
            ?>    
            </div>
        </div>
    </div>
<script type="text/javascript">  
    function reset_offer(){
        $("#main_category_err").css("display","none");
        document.getElementById('offer_details').value = "";
        document.getElementById('offer_id_hidden').value = "0";
        document.getElementById('offer_percentage').value = "";
        document.getElementById('max_offer').value = "";
        document.getElementById('min_order').value = "";
        document.getElementById('offer_type').value = "-1";
        document.getElementById('start_date').value = "";
        document.getElementById('end_date').value = "";
        document.getElementById('offer_status').value = "-1";
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
    }
    function edit_offer(id,offer_details,offer_percentage,max_offer,min_order,start_date,end_date,offer_type,offer_status){
        $("#main_category_err").css("display","none");
        start_date = start_date.replace(/ /g, "T");
        end_date = end_date.replace(/ /g, "T");
        document.getElementById('offer_details').value = offer_details;
        document.getElementById('offer_id_hidden').value = id;
        document.getElementById('offer_percentage').value = offer_percentage;
        document.getElementById('max_offer').value = max_offer;
        document.getElementById('min_order').value = min_order;
        document.getElementById('offer_type').value = offer_type;
        document.getElementById('start_date').value = start_date;
        document.getElementById('end_date').value = end_date;
        document.getElementById('offer_status').value = offer_status;
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
    }
    function add_offer(){
        $("#offer_err").css("display","none");
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
        var err = "";
        var number_reg = /^[+-]?\d+(\.\d+)?$/;
        var offer_details = document.getElementById('offer_details').value;
        var offer_percentage = document.getElementById('offer_percentage').value;
        var max_offer = document.getElementById('max_offer').value;
        var min_order = document.getElementById('min_order').value;
        var offer_type = document.getElementById('offer_type').value;
        var start_date = document.getElementById('start_date').value;
        var end_date = document.getElementById('end_date').value;
        var offer_status = document.getElementById('offer_status').value;
        var offer_id_hidden = document.getElementById('offer_id_hidden').value;
        if(offer_details == ""){
            err +=  '<li>Enter offer details</li>';
            document.getElementById("offer_details").classList.add("outline-red");
        }
        if(number_reg.test(offer_percentage) == false){
            err +=  '<li>Enter offer percentage</li>';
            document.getElementById("offer_percentage").classList.add("outline-red");
        }else{
            var z0to100 = /^(100(\.0{1,2})?|[1-9]?\d(\.\d{1,2})?)$/
            if(z0to100.test(offer_percentage) == false){
                err +=  '<li>Offer percentage should be 0 to 100</li>';
                document.getElementById("offer_percentage").classList.add("outline-red");
            }
        }
        if(number_reg.test(max_offer) == false){
            err +=  '<li>Enter max offer</li>';
            document.getElementById("max_offer").classList.add("outline-red");
        }
        if(number_reg.test(min_order) == false){
            err +=  '<li>Enter minimum order</li>';
            document.getElementById("min_order").classList.add("outline-red");
        }
        if(offer_type < 0){
            err +=  '<li>Select offer type</li>';
            document.getElementById("offer_type").classList.add("outline-red");
        }
        if(start_date == ""){
            err +=  '<li>Enter start date</li>';
            document.getElementById("start_date").classList.add("outline-red");
        }
        if(end_date == ""){
            err +=  '<li>Enter end date</li>';
            document.getElementById("end_date").classList.add("outline-red");
        }
        if(offer_status < 0){
            err +=  '<li>Select offer status</li>';
            document.getElementById("offer_status").classList.add("outline-red");
        }
        if(err != ""){
            console.log(err);           
            $("#offer_err").html("<ul>"+err+"</ul>");
            $("#offer_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "offer.php";
                    }else{
                        $("#offer_err").html("<ul>"+data.msg+"</ul>");
                        $("#offer_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("offer_details", offer_details);
            fd.append("offer_percentage", offer_percentage);
            fd.append("max_offer", max_offer);
            fd.append("min_order", min_order);
            fd.append("offer_type", offer_type);
            fd.append("start_date", start_date);
            fd.append("end_date", end_date);
            fd.append("offer_status", offer_status);
            fd.append("offer_id_hidden", offer_id_hidden);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");    
            ajaxRequest.open("POST", "add_offer_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    function delete_offer(id, details){    
        if(confirm("Are you sure to delete the "+details+" ? Press ok to confirm.")){    
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "offer.php";
                    }else{
                        $("#offer_err").html("<ul>"+data.msg+"</ul>");
                        $("#offer_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("offer_id", id);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "delete_offer_background.php", true);
            ajaxRequest.send(fd);
        }
    }
</script>
</body>
</html>