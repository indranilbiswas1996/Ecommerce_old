<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == false){
    header("Location: login.php");
}else{
    if($_SESSION['shop_uid'] == null || $_SESSION['shop_uid'] == ""){
        header("Location: shop.php");
    }
}
if(isset($_GET['id'])){
    $product_id = $_GET['id'];
}

?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
            <div class="dashboard-details-inner-container">
                <div class="product-img-container">
                    <div class="alert alert-danger" id="img_err"></div>
                    <div class="img-container add-img-container">
                        <div id="add_img_tag"  onclick="load_pic()">
                            <i class="fa fa-cloud-upload"></i>
                            <i>Add picture</i>
                        </div>
                        <input type="file" id="load_pic" style="display:none" accept="image/x-png,image/gif,image/jpeg"/> 
                    </div>
                    <div id="load_img_container">
                        <!--<div class="img-container">
                            <img src="img/1.jpeg"/>
                            <span class="fa fa-close red" onclick="delete_pic()"></span>
                        </div>
                        <div class="img-container">
                            <img src="img/3.jpeg"/>
                            <span class="fa fa-close red"></span>
                        </div>
                        <div class="img-container">
                            <img src="img/4.jpeg"/>
                            <span class="fa fa-close red"></span>
                        </div>
                        <div class="img-container">
                            <img src="img/5.jpeg"/>
                            <span class="fa fa-close red"></span>
                        </div>
                        -->
                    </div>
                </div>
                <div class="product-save-action-container">
                    <div class="product-save-action-div">
                        <button type="submit" class="login-button background-green" onclick="save()">Save</button>
                    </div>
                    <div class="product-save-action-div">
                        <button type="submit" class="login-button" onclick="reset()">Reset</button>
                    </div>
                </div>
                <!-- -->
            </div>
        </div>
    </div>
</body>
<script type="text/javascript">
    function load_pic(){
        document.getElementById("load_pic").click();
    }
    function showImage(src) {        
        var fr=new FileReader();
        // when image is loaded, set the src of the image where you want to display it
        fr.onload = function(e) { 
            if(src.files[0].size < 300000){
                var newdiv = document.createElement('div');
                newdiv.classList.add("img-container");
                newdiv.id = "load_img_id"+load_img_id;
                var newimg = document.createElement('img');
                newimg.src = this.result;
                var newspan = document.createElement('span');
                newspan.classList.add('fa', 'fa-close', 'red');
                newspan.setAttribute("onclick", "delete_load_pic("+load_img_id+")");
                newdiv.appendChild(newimg);
                newdiv.appendChild(newspan);
                document.getElementById('load_img_container').appendChild(newdiv);
                load_img_list.push(src.files[0]);
                load_img_id++;
            }else{
                alert("Product image should be less than 300KB");
            }
        };
        src.addEventListener("change",function() {
            // fill fr with image data    
            fr.readAsDataURL(src.files[0]);
        });        
    }
    var src = document.getElementById("load_pic");
    let load_img_id = 0;
    let load_img_list = [];
    showImage(src);

    function delete_load_pic(id){
        if(confirm("Are you sure to delete the product picture ? Press ok to confirm.")){  
            //load_img_list.splice(id, 1);
            delete load_img_list[id]
;           document.getElementById("load_img_id"+id).remove();
        }
    }

    function save(){
        var load_img_final_list = [];
        var j = 0;
        for(var i = 0; i<load_img_list.length; i++){
            if(load_img_list[i] != null){
                load_img_final_list[j] = load_img_list[i];
                j++;
            }
        }
        $("#img_err").css("display","none");
        var err = "";
        let err_flag = 0;
        if(load_img_final_list.length < 1){
            err +=  '<li>Select product image</li>';
            err_flag = 1;
        }
        if(err_flag == 0){
            /* Ajax */
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location.reload();
                    }else{
                        $("#img_err").html("<ul>"+data.msg+"</ul>");
                        $("#img_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            for(var i = 0; i<load_img_final_list.length ; i++){
                fd.append("img"+i+"", load_img_final_list[i]);
            }
            fd.append("load_img_final_list_length", load_img_final_list.length);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");    
            ajaxRequest.open("POST", "product_background.php", true);
            ajaxRequest.send(fd);
        }else{
            if(err_flag == 1){
                $("#img_err").html("<ul>"+err+"</ul>");
                $("#img_err").css("display","block");
            }
        }
    }
</script>
</html>