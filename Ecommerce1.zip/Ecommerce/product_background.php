<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                $load_img_final_list_length = htmlspecialchars($_POST["load_img_final_list_length"]);
                for($i = 0 ; $i < $load_img_final_list_length ; $i++){
                    $target_dir = 'img/';
                    $target_file = basename($_FILES["img".$i]["name"]);
                    $uploadFlag = 1;
                    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                    $new_name = hash('md5', date('dmY') . time() . mt_rand(1, 100));
                    $code = 400;
                    $msg = "Error";
                    if (file_exists($new_name . '.' . $imageFileType)) {
                        $code = 400;
                        $msg = "Sorry, file already exists.";
                        $uploadFlag = 0;
                    }
                    if ($_FILES["img".$i]["size"] > 300000) {
                        $code = 400;
                        $msg = "Sorry, your file is too large.";
                        $uploadFlag = 0;
                    }
                    if ($imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "jpeg" && $imageFileType != "JPEG" && $imageFileType != "jpg" && $imageFileType != "JPG" ) {
                        $code = 400;
                        $msg = "Sorry, only image files are allowed.";
                        $uploadFlag = 0;
                    }
                    if ($uploadFlag != 0) {
                        if (move_uploaded_file($_FILES["img".$i]["tmp_name"], 'img/' . $new_name . '.' . $imageFileType)) {
                            $fileName = $new_name . '.' . $imageFileType;
                            $code = 200;
                            $msg = "Success";
                        } 
                    }
                }
            }
            else{
                $code = 400;
                $msg = "Error";
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>