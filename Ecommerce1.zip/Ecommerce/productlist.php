<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == false){
    header("Location: login.php");
}else{
    if($_SESSION['shop_uid'] == null || $_SESSION['shop_uid'] == ""){
        header("Location: shop.php");
    }
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
            <div class="dashboard-details-inner-container">
                <div class="productlist-item-container">
                    <div class="productlist-item-img-container">
                        <div class="productlist-img-div">
                            <img src="img/1.jpeg">
                        </div>
                    </div>
                    <div class="productlist-item-details-container">
                        oiuyt<br>
                        oiuyt<br>
                        oiuyt<br>
                    </div>
                    <div class="productlist-item-price-container">
                        iuytr
                    </div>
                </div>
            </div>
        </div>
        
        <span class="" onclick="new_product()">New product</span>
    </div>
</body>
<script type="text/javascript">   
function new_product(){
    var ajaxRequest, fd;
    try {
        ajaxRequest = new XMLHttpRequest();
    }catch (e) {
        try {
            ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
        }catch (e) {
            try{
                ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
            }catch (e){
                alert("Your browser broke!");
                return false;
            }
        }
    }
    ajaxRequest.onreadystatechange = function(){
        if(ajaxRequest.readyState == 4){
            var data = JSON.parse(ajaxRequest.responseText);
            if(data.code == "200"){
                window.location = "product.php?id="+data.msg;
            }
        }
    }
    fd = new FormData();
    fd.append("xcsrf", "<?php echo $csrf_token;?>");          
    ajaxRequest.open("POST", "create_new_product_background.php", true);
    ajaxRequest.send(fd);
}
        
</script>
</html>