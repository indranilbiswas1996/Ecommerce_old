<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == true){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<div class="container">
    <div class="login-container">
        <div class="login-div">
            <div class="login-part">
                
                <!-- Registration -->
                <div class="login-part-inner" id="registration_div">
                    <div class="headline"><span>Registration</span></div>
                    <div class="alert alert-danger" id="registration_err">
                    </div>
                    <div class="login-item">
                        <label class="login-label">First name<span class="red">*</span></label>
                        <input type="text" name="f_name" id="f_name" class="login-textbox" placeholder="Enter first name">
                    </div>
                    <div class="login-item">
                        <label class="login-label">Last name</label>
                        <input type="text" name="l_name" id="l_name" class="login-textbox" placeholder="Enter last name">
                    </div>
                    <div class="login-item">
                        <label class="login-label">Gender : <span class="red">*</span></label>
                        <input type="radio" name="gender" value="1" checked> Male
                        <input type="radio" name="gender" value="2"> Female
                        <input type="radio" name="gender" value="3"> Other
                    </div>
                    <div class="login-item">
                        <label class="login-label">Mobile number<span class="red">*</span></label>
                        <input type="text" name="phone" id="phone" class="login-textbox" placeholder="Enter Mobile number">
                    </div>
                    <div class="login-item">
                        <label class="login-label">New password<span class="red">*</span></label>
                        <input type="password" name="n_password" id="n_password" class="login-textbox" placeholder="New password">
                    </div>
                    <div class="login-item">
                        <label class="login-label">Confirm password<span class="red">*</span></label>
                        <input type="password" name="c_password" id="c_password" class="login-textbox" placeholder="Confirm password">
                    </div>
                    <div class="login-item">
                        <button type="submit" class="login-button" name="submit" id="submit" onclick="registration()">Submit</button>
                    </div>
                    <div class="login-item">
                        <a href="slogin.php">Existing User? Log in</a>
                        <a href="forgot.php" class="right">Forgot password?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function registration(){
        var f_name = document.getElementById('f_name').value;
        var l_name = document.getElementById('l_name').value;
        var gender = document.querySelector('input[name = gender]:checked').value;
        var phone = document.getElementById('phone').value;
        var n_password = document.getElementById('n_password').value;
        var c_password = document.getElementById('c_password').value;
        var err = "";
        if(f_name==""){
            err +=  '<li>Enter First name</li>'; 
            document.getElementById("f_name").classList.add("outline-red");
        }
        if(gender<1 && gender > 3){
            err +=  '<li>Select gender</li>';
            document.querySelector('input[name = gender]:checked').classList.add("outline-red");
        }
        if(phone == ""){
            err +=  '<li>Enter mobile number</li>';
            document.getElementById("phone").classList.add("outline-red");
        }else{
            var mob = /^[6-9]{1}[0-9]{9}$/;
            if (mob.test(phone) == false) {
                err +=  '<li>Enter 10 digit mobile number</li>';
                document.getElementById("phone").classList.add("outline-red");
            }
        }
        if(n_password==""){
            err +=  '<li>Enter password</li>'; 
            document.getElementById("n_password").classList.add("outline-red");
        }
        if(c_password==""){
            err +=  '<li>Enter confirm password</li>'; 
            document.getElementById("c_password").classList.add("outline-red");
        }
        if(err != ""){          
            $("#registration_err").html("<ul>"+err+"</ul>");
            $("#registration_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "otp.php";
                    }else{
                        $("#registration_err").html("<ul>"+data.msg+"</ul>");
                        $("#registration_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("f_name", f_name);
            fd.append("l_name", l_name);
            fd.append("gender", gender);
            fd.append("phone", phone);   
            fd.append("n_password", n_password);
            fd.append("c_password", c_password);   
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "registration_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    
</script>
</body>
</html>