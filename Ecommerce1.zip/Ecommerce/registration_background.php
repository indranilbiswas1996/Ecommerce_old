<?php
include_once 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() != true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $f_name = htmlspecialchars($_POST["f_name"]);
            $l_name = htmlspecialchars($_POST["l_name"]);
            $gender = htmlspecialchars($_POST["gender"]);
            $phone = htmlspecialchars($_POST["phone"]);
            $n_password = htmlspecialchars($_POST["n_password"]);
            $c_password = htmlspecialchars($_POST["c_password"]);
            if(empty($_POST["f_name"])){
                $code = 400;
                $msg .= "<li>Enter First name</li>";
            }
            if(empty($_POST["gender"])){
                $code = 400;
                $msg .= "<li>Select gender</li>";
            }
            if(empty($_POST["phone"])){
                $code = 400;
                $msg .= "<li>Enter Mobile no</li>";
            }else{
                if(!preg_match("/^[6-9]{1}[0-9]{9}$/", $phone)) {
                    $code = 400;
                    $msg .= "<li>Invalid mobile number</li>";
                }
            }
            /*if(empty($_POST["email"])){
                $msg .= "<li>Enter Email name</li>";
            }else{
                $email = $_POST["email"];
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $msg .= "<li>Invalid Email format</li>";
                }
            }*/
            if(empty($_POST["n_password"])){
                $code = 400;
                $msg .= "<li>Enter New password</li>";
            }
            if(empty($_POST["c_password"])){
                $code = 400;
                $msg .= "<li>Enter Confirm password</li>";
            }
            if(!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $_POST["n_password"])) {
                $code = 400;
                $msg .= '<li>Week password!</li>';
                $msg .= "Use at least 8 to 12 characters</br>";
                $msg .= "Use 1 or more alphabet</br>";
                $msg .= "Use 1 or more number</br>";
                $msg .= "Use 1 or more special characters";
            }
            if($c_password != $n_password) {
                $code = 400;
                $msg .= "<li>Password does not match</li>";
            }
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $stmt = $conn->prepare("SELECT id FROM admin WHERE phone = ?");
                $stmt->bind_param('s', $phone);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id);
                if($stmt->num_rows() == 0){
                    $zero = 0;
                    $one = 1;
                    $password_hash = make_hash($c_password);

                    //Create OTP
                    $generator = "135792468"; 
                    $phone_otp = "";   
                    for ($i = 1; $i <= 6; $i++) { 
                        $phone_otp .= substr($generator, (rand()%(strlen($generator))), 1); 
                    } 
                    $email_otp = "";   
                    for ($i = 1; $i <= 6; $i++) { 
                        $email_otp .= substr($generator, (rand()%(strlen($generator))), 1); 
                    } 
                    //To set IST time
                    date_default_timezone_set('Asia/Kolkata');
                    $created_time = date('Y-m-d h:i:s');

                    $stmt2 = $conn->prepare("INSERT INTO admin (f_name,l_name,gender,phone,verify_phone,password,admin_type, admin_status, created_time) VALUES (?,?,?,?,?,?,?,?,?)");        
                    $stmt2->bind_param('sssssssss', $f_name, $l_name, $gender, $phone, $zero, $password_hash, $one, $zero, $created_time);
                    $stmt2->execute();

                    $stmt2 = $conn->prepare("INSERT INTO admin_otp (phone,phone_otp,p_send_count,p_created_time,email_otp,e_send_count,e_created_time) VALUES (?,?,?,?,?,?,?)");        
                    $stmt2->bind_param('sssssss', $phone, $phone_otp, $one, $created_time, $email_otp, $one, $created_time);
                    $stmt2->execute();
                    $stmt2->close();
                    
                    /* SMS and Mail*/
                    sendsmsotp($phone, $phone_otp);
                    sendemailotp($phone, $email_otp);

                    $_SESSION['phone'] = $phone;
                    $_SESSION['f_name'] = $f_name;
                    $_SESSION['admin_status'] = $zero;
                    $_SESSION['shop_uid'] = "";

                    $code = 200;
                    $msg = "Success";
                }else{
                    $code = 400;
                    $msg = "Mobile number already exist";
                }
                $stmt->close();
                $conn->close();
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>