<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$res = '{"error": 3}';
if(isset($_POST['xcsrf']) ){      

    if($_POST['xcsrf'] == $csrf_token) {
        include 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
        $state = htmlspecialchars($_POST['state']);
        $display_string = "";   
        
            $stmt = $conn->prepare("SELECT city_name, city_code FROM `all_cities` WHERE state_code = ?");        
            $stmt->bind_param('s', $state);
            $stmt->execute();
            $stmt->store_result();
            if($stmt->num_rows() != 0){                    
                $stmt->bind_result($city_code, $city_name);   
                $display_string = '[';
                while($stmt->fetch()){    
                    $display_string .= '{"id": "'.$city_code.'", "value":"'.$city_name.'"},';        
                }
                $display_string = substr($display_string, 0, strlen($display_string) -1);
                $display_string .=']';
            }
        
        $stmt->close();
        $conn->close();
        $res = '{"error": 0, "msg": "Successfully added!"}';
    }
}
echo $display_string;
?>