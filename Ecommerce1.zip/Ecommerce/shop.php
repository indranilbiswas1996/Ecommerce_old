<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() != true){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<div class="container">
    <div class="shop-container">
    <div class="alert alert-danger" id="login_err"></div>
        <div class="shop-container-inner">
            <h4>Shop information</h4>
            <div class="alert alert-danger" id="info_err"></div>
            <div class="shop-container-div-3">
                <label class="login-label">Shop name<span class="red">*</span></label>
                <input type="text" name="shop_name" id="shop_name" class="login-textbox" placeholder="Enter shop name">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Shop type<span class="red">*</span></label>
                <select id="shop_type" name="shop_type" class="login-selectbox">
                    <option value="-1">Select shop type</option>
                    <?php
                    include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                        $one = 1;
                        $stmt = $conn->prepare("SELECT id, shop_type_details FROM shop_type WHERE status = ?");
                        $stmt->bind_param('s', $one);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                    
                            $stmt->bind_result($id, $shop_type_details);
                            while($stmt->fetch()){
                                echo '<option value="'.$id.'">'.$shop_type_details.'</option>';
                            }
                        }
                        $stmt->close();
                    ?>                            
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Shop mobile number<span class="red">*</span></label>
                <input type="text" name="phone" id="phone" class="login-textbox" placeholder="Enter mobile number" value="<?php echo $_SESSION['phone']; ?>">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Shop alternet mobile number</label>
                <input type="text" name="alternet_phone" id="alternet_phone" class="login-textbox" placeholder="Enter alternet mobile number">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Shop enter id</label>
                <input type="text" name="email" id="email" class="login-textbox" placeholder="Enter email id">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Shop alternet email id</label>
                <input type="text" name="alternet_email" id="alternet_email" class="login-textbox" placeholder="Enter alternet email id">
            </div>
        </div>
        <div class="shop-container-inner">
            <h4>Address</h4>
            <div class="alert alert-danger" id="address_err"></div>
            <div class="shop-container-div-3">
                <label class="login-label">Locality<span class="red">*</span></label>
                <input type="text" name="locality" id="locality" class="login-textbox" placeholder="Enter locality">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Address<span class="red">*</span></label>
                <input type="text" name="address" id="address" class="login-textbox" placeholder="Enter address">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">State<span class="red">*</span></label>
                <select id="state" name="state" class="login-selectbox">
                    <option value="-1">Select state</option>
                    <?php
                        $one = 1;
                        $stmt = $conn->prepare("SELECT state_code, state_name FROM all_states");
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                    
                            $stmt->bind_result($state_code, $state_name);
                            while($stmt->fetch()){
                                echo '<option value="'.$state_code.'">'.$state_name.'</option>';
                            }
                        }
                        $stmt->close();
                    ?>                            
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">District<span class="red">*</span></label>
                <select id="dist" name="dist" class="login-selectbox">
                    <option value="-1">Select district</option>                            
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Pin code<span class="red">*</span></label>
                <input type="number" name="pin" id="pin" class="login-textbox" placeholder="Enter pin no">
            </div>
        </div>
        <div class="shop-container-inner">
            <h4>Proof details</h4>
            <div class="alert alert-danger" id="proof_err"></div>
            <div class="shop-container-div-3">
            <label class="login-label">Govt proof type<span class="red">*</span></label>
            <select id="govt_proof" name="govt_proof" class="login-selectbox">
                    <option value="-1">Select Govt proof type</option>
                    <?php
                        $one = 1;
                        $stmt = $conn->prepare("SELECT id, govt_proof_details FROM govt_proof WHERE status = ?");
                        $stmt->bind_param('s', $one);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                    
                            $stmt->bind_result($id, $govt_proof_details);
                            while($stmt->fetch()){
                                echo '<option value="'.$id.'">'.$govt_proof_details.'</option>';
                            }
                        }
                        $stmt->close();
                        $conn->close();
                    ?>                            
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Govt proof id<span class="red">*</span></label>
                <input type="text" name="govt_proof_no" id="govt_proof_no" class="login-textbox" placeholder="Enter id">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">GST number</label>
                <input type="text" name="gst" id="gst" class="login-textbox" placeholder="Enter GST">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">PAN card</label>
                <input type="text" name="pan" id="pan" class="login-textbox" placeholder="Enter PAN">
            </div>
        </div>
        <div class="shop-save-div">
            <button type="submit" class="login-button" name="shop" id="shop" onclick="shop()">Save</button>
        </div>
    </div>
    
</div>
<script type="text/javascript">
    function shop(){
        $("#info_err").css("display","none");        
        $("#address_err").css("display","none");
        $("#proof_err").css("display","none");
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
        var err = "";
        var err_flag = 0;
        var shop_name=document.getElementById('shop_name').value;
        var shop_type=document.getElementById('shop_type').value;
        var phone=document.getElementById('phone').value;
        var alternet_phone=document.getElementById('alternet_phone').value;
        var email=document.getElementById('email').value;
        var alternet_email=document.getElementById('alternet_email').value;
        var locality=document.getElementById('locality').value;
        var address=document.getElementById('address').value;
        var state=document.getElementById('state').value;
        var dist=document.getElementById('dist').value;
        var pin=document.getElementById('pin').value;
        var govt_proof=document.getElementById('govt_proof').value;
        var govt_proof_no=document.getElementById('govt_proof_no').value;
        var gst=document.getElementById('gst').value;
        var pan=document.getElementById('pan').value;
        if (shop_name == "") {
            err_flag++;
            err += "<li>Enter shop name</li>";
            document.getElementById("shop_name").classList.add("outline-red");
        }
        if (shop_type <= 0) {
            err_flag++;
            err += "<li>Enter shop type</li>";
            document.getElementById("shop_type").classList.add("outline-red");
        }
        var mob = /^[6-9]{1}[0-9]{9}$/;        
        if(phone == ""){
            err_flag++;
            err += "<li>Enter mobile no</li>";
            document.getElementById("phone").classList.add("outline-red");
        }else{
            if (mob.test(phone) == false) {
            err_flag++;
                err += "<li>Invalid mobile no</li>";
                document.getElementById("phone").classList.add("outline-red");
            }
        }
        if(alternet_phone != ""){
            if (mob.test(alternet_phone) == false) {
                err_flag++;
                err += "<li>Invalid alternet mobile no</li>";
                document.getElementById("alternet_phone").classList.add("outline-red");
            }
        }
        var email_reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;        
        if(email != ""){
            if (email_reg.test(email) == false) {
                err_flag++;
                err += "<li>Invalid email id</li>";
                document.getElementById("email").classList.add("outline-red");
            }
        }
        if(alternet_email != ""){
            if (email_reg.test(alternet_email) == false) {
                err_flag++;
                err += "<li>Invalid alternet email id</li>";
                document.getElementById("alternet_email").classList.add("outline-red");
            }
        }
        if(err != ""){
            $("#info_err").html("<ul>"+err+"</ul>");
            $("#info_err").css("display","block");
        }
        err = "";
        if (locality == "") {
            err_flag++;
            err += "<li>Enter locality</li>";
            document.getElementById("locality").classList.add("outline-red");
        }
        if (address == "") {
            err_flag++;
            err += "<li>Enter address</li>";
            document.getElementById("address").classList.add("outline-red");
        }
        if (state <= 0) {
            err_flag++;
            err += "<li>Select state</li>";
            document.getElementById("state").classList.add("outline-red");
        }
        if (dist <= 0) {
            err_flag++;
            err += "<li>Select district</li>";
            document.getElementById("dist").classList.add("outline-red");
        }
        var pin_p = /^[0-9]{6}$/;   
        if (pin == "") {
            err_flag++;
            err += "<li>Enter pin no</li>";
            document.getElementById("pin").classList.add("outline-red");
        }else{
            if (pin_p.test(pin) == false) {
                err_flag++;
                err += "<li>Invalid pin no</li>";
                document.getElementById("pin").classList.add("outline-red");
            }
        }
        if(err != ""){
            $("#address_err").html("<ul>"+err+"</ul>");
            $("#address_err").css("display","block");
        }
        err = "";
        if (govt_proof <= 0) {
            err_flag++;
            err += "<li>Select Govt proof type</li>";
            document.getElementById("govt_proof").classList.add("outline-red");
        }
        if (govt_proof_no <= 0) {
            err_flag++;
            err += "<li>Enter Govt proof id</li>";
            document.getElementById("govt_proof_no").classList.add("outline-red");
        }
        if(err != ""){
            $("#proof_err").html("<ul>"+err+"</ul>");
            $("#proof_err").css("display","block");
        }
        if(err_flag == 0){
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "index.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("shop_name", shop_name);
            fd.append("shop_type", shop_type);
            fd.append("phone", phone);
            fd.append("alternet_phone", alternet_phone);
            fd.append("email", email);
            fd.append("alternet_email", alternet_email);
            fd.append("locality", locality);
            fd.append("address", address);
            fd.append("state", state);
            fd.append("dist", dist);
            fd.append("pin", pin);
            fd.append("govt_proof", govt_proof);
            fd.append("govt_proof_no", govt_proof_no);
            fd.append("gst", gst);
            fd.append("pan", pan);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "shop_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    $(document).ready(function () {
        $("#state").change(function () {
            var state = $(this).val();
            if(state >= 0){
                var ajaxRequest, fd;
                try {
                    ajaxRequest = new XMLHttpRequest();
                }catch (e) {
                    try {
                        ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                    }catch (e) {
                        try{
                            ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                        }catch (e){
                            alert("Your browser broke!");
                            return false;
                        }
                    }
                }
                ajaxRequest.onreadystatechange = function(){
                    if(ajaxRequest.readyState == 4){
                        var data = JSON.parse(ajaxRequest.responseText);
                        //dist//
                        var select = document.getElementById('dist');
                        $("#dist").empty();
                        var opt = document.createElement('option');
                        opt.value = -1;
                        opt.innerHTML = "Select district";
                        select.appendChild(opt);
                        
                        for (var i = 0; i<data.length; i++){  
                            var opt = document.createElement('option');                              
                            opt.value = data[i].value;
                            opt.innerHTML = data[i].id;
                            select.appendChild(opt);
                        }
                    }
                }
                fd = new FormData();
                fd.append("state", state);
                fd.append("xcsrf", "<?php echo $csrf_token;?>");            
                ajaxRequest.open("POST", "selectdist.php", true);
                ajaxRequest.send(fd);
                
            }
        });
    });
</script>
</body>
</html>