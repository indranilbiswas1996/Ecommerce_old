<?php
date_default_timezone_set('Asia/Kolkata');
$p_resend_time = date('YmdGis').rand(100,999);
echo md5($p_resend_time);;
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<div class="container">
    <?php include 'header.php';?>
    <div class="control-container">
        <div class="control-option">
            <a href="#">Upload Product</a>
        </div>
        <div class="control-option">
            <a href="#">Products</a>
        </div>
        <div class="control-option">
            <a href="#">Orders</a>
        </div>
        <div class="control-option">
            <a href="#">Accepted</a>
        </div>
        <div class="control-option">
            <a href="#">Deleted</a>
        </div>
        <div class="control-option">
            <a href="#">Delivered</a>
        </div>
    </div>
</div>
    
    <img src="icons/banner.png" class="banner"/>
</body>
</html>